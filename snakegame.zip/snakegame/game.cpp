#include "game.hpp"
#include <iostream>
#include <string>
#include <ctime>

Game::Game()
{
    for (int i = 0; i < GRID_WIDTH; ++i)
    {
        for (int j = 0; j < GRID_HEIGHT; ++j)
        {
            grid[i][j] = Block::empty;
        }
    }
    srand(static_cast<unsigned int>(time(0)));
}

void Game::run()
{
    if (SDL_Init(SDL_INIT_VIDEO < 0))
    {
        std::cerr << "SDL could not initialize! SDL_Error: " << SDL_GetError() << std::endl;
        exit(EXIT_FAILURE);
    }

    window = SDL_CreateWindow("Snake Game", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED,
                              SCREEN_WIDTH, SCREEN_HEIGHT, SDL_WINDOW_SHOWN);
    if (window == nullptr)
    {
        std::cerr << "Window could not be created! SDL_Error: " << SDL_GetError() << std::endl;
        exit(EXIT_FAILURE);
    }

    renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);
    if (renderer == nullptr)
    {
        std::cerr << "Renderer could not be created! SDL_Error: " << SDL_GetError() << std::endl;
        exit(EXIT_FAILURE);
    }

    alive = true;
    running = true;
    replaceFood();
    gameLoop();
}

void Game::replaceFood()
{
    int x, y;
    while (true)
    {
        x = rand() % GRID_WIDTH;
        y = rand() % GRID_HEIGHT;

        if (grid[x][y] == Block::empty)
        {
            grid[x][y] = Block::food;
            food.x = x;
            food.y = y;
            break;
        }
    }
}

void Game::gameLoop()
{
    Uint32 before, after;
    Uint32 second = SDL_GetTicks();
    int frameTime;
    int frames = 0;

    while (running)
    {
        before = SDL_GetTicks();
        pollEvents();
        update();
        render();

        frames++;
        after = SDL_GetTicks();
        frameTime = after - before;

        if (after - second >= 1000)
        {
            fps = frames;
            frames = 0;
            second = after;
            updateWindow();
        }
        if (FRAME_RATE > frameTime)
        {
            SDL_Delay(FRAME_RATE - frameTime);
        }
    }
}

void Game::pollEvents()
{
    SDL_Event e;
    while (SDL_PollEvent(&e))
    {
        if (e.type == SDL_QUIT)
        {
            running = false;
        }
        else if (e.type == SDL_KEYDOWN)
        {
            switch (e.key.keysym.sym)
            {
            case SDLK_UP:
                if (last_dir != Move::down || size == 1)
                    dir = Move::up;
                break;

            case SDLK_DOWN:
                if (last_dir != Move::up || size == 1)
                    dir = Move::down;
                break;

            case SDLK_LEFT:
                if (last_dir != Move::right || size == 1)
                    dir = Move::left;
                break;

            case SDLK_RIGHT:
                if (last_dir != Move::left || size == 1)
                    dir = Move::right;
                break;
            }
        }
    }
}

int Game::getSize()
{
    return size;
}

void Game::growBody(int quantity)
{
    growing += quantity;
}

void Game::update()
{
    if (!alive)
        return;

    switch (dir)
    {
    case Move::up:
        pos.y -= speed;
        pos.x = floorf(pos.x);
        break;
    case Move::down:
        pos.y += speed;
        pos.x = floorf(pos.x);
        break;

    case Move::left:
        pos.x -= speed;
        pos.y = floorf(pos.y);
        break;

    case Move::right:
        pos.x += speed;
        pos.y = floorf(pos.y);
        break;
    }
    if (pos.x < 0)
        pos.x = GRID_WIDTH - 1;
    else if (pos.x > GRID_WIDTH - 1)
        pos.x = 0;

    if (pos.y < 0)
        pos.y = GRID_HEIGHT - 1;
    else if (pos.y > GRID_HEIGHT - 1)
        pos.y = 0;

    int new_x = static_cast<int>(pos.x);
    int new_y = static_cast<int>(pos.y);

    // Check if head position has changed
    if (new_x != head.x || new_y != head.y)
    {
        last_dir = dir;

        // If we are growing, just make a new neck
        if (growing > 0)
        {
            size++;
            body.push_back(head);
            growing--;
            grid[head.x][head.y] = Block::body;
        }
        else
        {
            // We need to shift the body
            SDL_Point free = head;
            std::vector<SDL_Point>::reverse_iterator rit = body.rbegin();
            for (; rit != body.rend(); ++rit)
            {
                grid[free.x][free.y] = Block::body;
                std::swap(*rit, free);
            }

            grid[free.x][free.y] = Block::empty;
        }
    }

    head.x = new_x;
    head.y = new_y;

    Block &next = grid[head.x][head.y];
    // Check if there's food over here
    if (next == Block::food)
    {
        score++;
        replaceFood();
        growBody(1);
    }
    // Check if we're dead
    else if (next == Block::body)
    {
        alive = false;
    }

    next = Block::head;
}

int Game::getScore()
{
    return score;
}

void Game::updateWindow()
{
    std::string title = "Snakle++ Score: " + std::to_string(score) + " FPS: " + std::to_string(fps);
    SDL_SetWindowTitle(window, title.c_str());
}

void Game::render()
{
    SDL_Rect block;
    block.w = SCREEN_WIDTH / GRID_WIDTH;
    block.h = SCREEN_WIDTH / GRID_HEIGHT;

    // Clear screen
    SDL_SetRenderDrawColor(renderer, 0x1E, 0x1E, 0x1E, 0xFF);
    SDL_RenderClear(renderer);

    // Render food
    SDL_SetRenderDrawColor(renderer, 0xFF, 0xCC, 0x00, 0xFF);
    block.x = food.x * block.w;
    block.y = food.y * block.h;
    SDL_RenderFillRect(renderer, &block);

    // Render snake's body
    SDL_SetRenderDrawColor(renderer, 0xFF, 0xFF, 0xFF, 0xFF);
    for (SDL_Point &point : body)
    {
        block.x = point.x * block.w;
        block.y = point.y * block.h;
        SDL_RenderFillRect(renderer, &block);
    }

    // Render snake's head
    block.x = head.x * block.w;
    block.y = head.y * block.h;
    if (alive)
        SDL_SetRenderDrawColor(renderer, 0x00, 0x7A, 0xCC, 0xFF);
    else
        SDL_SetRenderDrawColor(renderer, 0xFF, 0x00, 0x00, 0xFF);
    SDL_RenderFillRect(renderer, &block);

    // Update Screen
    SDL_RenderPresent(renderer);
}

void Game::close()
{
    SDL_DestroyWindow(window);
    SDL_Quit();
}
