#include "game.hpp"
#include <iostream>

int main()
{
    Game game;
    game.run();
    std::cout << "Game has terminated successfully, score: " << game.getScore()
              << ", size: " << game.getSize() << '\n';
    return 0;
}