#pragma once
#include <vector>
#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>

class Game
{
public:
    Game();
    void run();
    int getScore();
    int getSize();

private:
    bool running = false;
    bool alive = false;
    int fps = 0;

    static const int FRAME_RATE = 1000 / 60;
    static const int SCREEN_WIDTH = 640;
    static const int SCREEN_HEIGHT = 640;
    static const int GRID_WIDTH = 32;
    static const int GRID_HEIGHT = 32;

    SDL_Window *window = nullptr;
    SDL_Renderer *renderer = nullptr;

    enum class Block
    {
        head,
        body,
        food,
        empty
    };
    enum class Move
    {
        up,
        down,
        right,
        left
    };

    Move last_dir = Move::up;
    Move dir = Move::up;

    struct
    {
        float x = GRID_WIDTH / 2, y = GRID_HEIGHT / 2;
    } pos;

    SDL_Point head = {static_cast<int>(pos.x), static_cast<int>(pos.y)};
    SDL_Point food;
    std::vector<SDL_Point> body;

    Block grid[GRID_WIDTH][GRID_HEIGHT];

    float speed = 0.3f;
    int growing = 0;
    int size = 1;
    int score = 0;

    void replaceFood();
    void growBody(int quantity);
    void updateWindow();
    void gameLoop();
    void render();
    void update();
    void pollEvents();
    void close();
};